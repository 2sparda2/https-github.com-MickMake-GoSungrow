//go:build !(freebsd && amd64)
package cmdModbus

const (
	DefaultPort = "502"
)
